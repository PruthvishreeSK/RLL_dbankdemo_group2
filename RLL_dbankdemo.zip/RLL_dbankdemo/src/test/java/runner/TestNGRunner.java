package runner;

import org.junit.runner.RunWith;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//import io.cucumber.junit.CucumberOptions;
import utilities.ITestListenerClass;

//@RunWith(Cucumber.class)
//@Listeners(value= {ITestListenerClass.class})
@CucumberOptions(features="C:\\Users\\HP\\eclipse-workspace\\RLL_dbankdemo\\src\\test\\java\\features",
glue={"stepDefinitions","pages"},
plugin= {"pretty","html:target/sample.html",
		"json:target/stepdefinition.json","junit:target/stepReport.xml",
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:targer/extentsampleReport.html"},
		monochrome =true)

public class TestNGRunner extends AbstractTestNGCucumberTests  
{
	//Runs each cucumber scenario found in the features as separated test
	
}